<a href="javascript:;" id="show_menu">&raquo;</a>
<div id="left_menu">
	<a href="javascript:;" id="hide_menu">&laquo;</a>
	<ul id="main_menu">
		<li><a href="<?=SITE_PATH.'/ermanager'?>"><img src="images/home.png" alt="" width="25"/>Home</a></li>
<!--		<li><a href="index.php?do=menus"><img src="images/menus.png" alt="" width="25"/>Menus</a></li>-->
<!--		<li><a href="index.php?do=sliders"><img src="images/sliders.png" alt="" width="25"/>Sliders</a></li>-->
		<li><a href="index.php?do=projects"><img src="images/news.png" alt="" width="25"/>Projects</a></li>
<!--		<li><a href="index.php?do=gallery"><img src="images/gallery.png" alt="" width="25"/>Gallery</a></li>-->
<!--		<li><a href="index.php?do=about"><img src="images/about.png" alt="" width="25"/>About</a></li>-->
<!--		<li><a href="index.php?do=categories"><img src="images/categories.png" alt="" width="25"/>Categories</a></li>-->
<!--		<li><a href="index.php?do=products"><img src="images/products.png" alt="" width="25"/>Products</a></li>-->
<!--		<li><a href="index.php?do=news"><img src="images/news.png" alt="" width="25"/>News</a></li>-->
<!--        <li><a href="index.php?do=partners"><img src="images/works.png" alt="" width="25"/>Partners</a></li>-->
<!--		<li><a href="index.php?do=experience"><img src="images/experience.png" alt="" width="25"/>Experience</a></li>-->
<!--		<li><a href="index.php?do=projects"><img src="images/projects.png" alt="" width="25"/>Projects</a></li>-->
<!--        <li><a href="index.php?do=projects_gallery"><img src="images/gallery.png" alt="" width="25"/>Projects gallery</a></li>-->
<!--		<li><a href="index.php?do=tags"><img src="images/tags.png" alt="" width="25"/>Tags</a></li>-->
        <li><a href="index.php?do=contacts"><img src="images/contacts.png" alt="" width="25"/>Contacts</a></li>
        <li><a href="index.php?do=uploader"><img src="images/uploader.png" alt="" width="25"/>Uploader</a></li>
<!--        <li><a href="index.php?do=gallery"><img src="images/gallery.png" alt="" width="25"/>Gallery</a></li>-->
<!--        <li><a href="index.php?do=slider"><img src="images/sliders.png" alt="" width="25"/>Slider</a></li>-->
<!--        <li><a href="index.php?do=faq"><img src="images/faq.png" alt="" width="25"/>F.A.Q</a></li>-->
<!--		<li><a href="index.php?do=slider"><img src="images/sliders.png" alt="" width="25"/>Slaydlar</a></li>-->
<!--		<li><a href="index.php?do=products"><img src="images/works.png" alt="" width="25"/>Məhsullar</a></li>-->
<!--        <li><a href="index.php?do=blog"><img src="images/news.png" alt="" width="25"/>Xəbərlər</a></li>-->
<!--        <li><a href="index.php?do=news_gallery"><img src="images/sliders.png" alt="" width="25"/>Xəbərlər (Qalereya)</a></li>-->
<!--		<li><a href="index.php?do=works"><img src="images/works.png" alt="" width="25"/>İşlərimiz</a></li>-->
<!--        <li><a href="index.php?do=works_gallery"><img src="images/sliders.png" alt="" width="25"/>İşlərimiz (Qalereya)</a></li>-->
<!--		<li><a href="index.php?do=contacts"><img src="images/contacts.png" alt="" width="25"/>Contacts</a></li>-->

		<li><a href="index.php?do=seo"><img src="images/seoopt.png" alt="" width="25"/>Seo Opt.</a></li>

		<li><a href="javascript::void(0);">&nbsp;&nbsp;</a></li>

		<li><a href="index.php?do=diller"><img src="images/lang.png" alt="" width="25"/>Languages</a></li>
		<li><a href="index.php?do=admin_pass"><img src="images/admin.png" alt="" width="25"/>Administration</a></li>
		<li><a href="logout.php"><img src="images/logout.png" alt="" width="25"/>Logout</a></li>
<!--		<li><a href="index.php?do=users"><img src="images/users.png" alt="" width="25"/>İstifadəçilər</a></li>-->
	</ul>
	<br class="clear"/>	
</div>
<?php
/*

*/
?>