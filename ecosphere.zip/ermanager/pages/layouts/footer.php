<br class="clear"/>
<div id="footer">
	<!-- &copy; Copyright 2013 by Develop Group | Develop.az -->
</div>