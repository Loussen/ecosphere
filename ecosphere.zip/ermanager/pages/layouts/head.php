<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
<!-- Website Title --> 
<title>Admin Panel</title>
<link rel="icon" href="../images/favicon.ico" type="image/x-icon">
<link href="css/screen.css" rel="stylesheet" type="text/css" media="all">
<link href="js/visualize/visualize.css" rel="stylesheet" type="text/css" media="all">
<link href="js/fancybox/jquery.fancybox-1.3.0.css" rel="stylesheet" type="text/css" media="all">
<link href="css/multiselect.css" media="screen" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.css" rel="stylesheet" type="text/css" media="all">
<!--[if IE]>
	<link href="css/ie.css" rel="stylesheet" type="text/css" media="all">
	<script type="text/javascript" src="js/excanvas.js"></script>
<![endif]-->
<!-- Jquery and plugins -->
<script type="text/javascript" src="js/jquery-1.9.1.js"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
<script type="text/javascript" src="js/visualize/jquery.visualize.js"></script>
<script type="text/javascript" src="js/fancybox/jquery.fancybox-1.3.0.js"></script>
<script src="js/jquery.multi-select.js" type="text/javascript"></script>
<script src="js/jquery.quicksearch.js" type="text/javascript"></script>
<script type="text/javascript" src="js/custom_green.js"></script>
<script type="text/javascript" src="js/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript" src="js/browser.js"></script>
<script type="text/javascript" src="js/jquery_e.js"></script>
<link href="css/jquery-ui.css" rel="stylesheet" type="text/css" media="all">

<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/tagmanager/3.0.2/tagmanager.min.css">
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/tagmanager/3.0.2/tagmanager.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>

<style>
    ul#main_menu li
    {
        font-size: 11px;
    }
</style>